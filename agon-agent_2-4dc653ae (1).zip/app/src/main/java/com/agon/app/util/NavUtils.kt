package com.agon.app.util

import java.net.URLDecoder
import java.net.URLEncoder

object NavUtils {
    fun encodePhoneNumber(phone: String): String {
        return URLEncoder.encode(phone, "UTF-8")
    }
    
    fun decodePhoneNumber(encoded: String): String {
        return URLDecoder.decode(encoded, "UTF-8")
    }
}
