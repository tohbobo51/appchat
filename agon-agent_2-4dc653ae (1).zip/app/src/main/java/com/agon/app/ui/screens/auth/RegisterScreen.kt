package com.agon.app.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.ui.theme.WhatsAppGreen
import com.agon.app.ui.theme.WhatsAppLightGreen
import com.agon.app.viewmodel.AuthState
import com.agon.app.viewmodel.AuthViewModel

@Composable
fun RegisterScreen(
    phoneNumber: String,
    viewModel: AuthViewModel,
    onRegistrationSuccess: () -> Unit
) {
    val authState by viewModel.authState.collectAsState()
    var username by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    
    LaunchedEffect(authState) {
        when (authState) {
            is AuthState.Success -> {
                onRegistrationSuccess()
                viewModel.resetAuthState()
            }
            else -> {}
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Icon
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(WhatsAppLightGreen.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    modifier = Modifier.size(50.dp),
                    tint = WhatsAppGreen
                )
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            Text(
                text = "Create your profile",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = "Phone: $phoneNumber",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Username
            OutlinedTextField(
                value = username,
                onValueChange = { 
                    username = it.lowercase().filter { char -> char.isLetterOrDigit() || char == '_' || char == '.' }
                    isError = false
                },
                label = { Text("Username") },
                placeholder = { Text("johndoe") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                isError = isError && username.length < 3,
                supportingText = { 
                    Text("Username for others to find you (min 3 characters)")
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = WhatsAppGreen,
                    focusedLabelColor = WhatsAppGreen
                )
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Display Name
            OutlinedTextField(
                value = displayName,
                onValueChange = { 
                    displayName = it
                    isError = false
                },
                label = { Text("Display Name") },
                placeholder = { Text("John Doe") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                isError = isError && displayName.isBlank(),
                supportingText = { 
                    Text("Your name as shown to others")
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = WhatsAppGreen,
                    focusedLabelColor = WhatsAppGreen
                )
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            if (authState is AuthState.Loading) {
                CircularProgressIndicator(color = WhatsAppGreen)
            } else {
                Button(
                    onClick = {
                        if (username.length >= 3 && displayName.isNotBlank()) {
                            viewModel.register(phoneNumber, username, displayName)
                        } else {
                            isError = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                    enabled = username.length >= 3 && displayName.isNotBlank()
                ) {
                    Text("COMPLETE REGISTRATION", fontWeight = FontWeight.Bold)
                }
            }
            
            if (authState is AuthState.Error) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = (authState as AuthState.Error).message,
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 14.sp
                )
            }
        }
    }
}
