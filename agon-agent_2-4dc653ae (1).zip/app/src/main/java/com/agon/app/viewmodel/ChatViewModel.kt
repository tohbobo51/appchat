package com.agon.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.agon.app.data.model.Chat
import com.agon.app.data.model.ChatWithContact
import com.agon.app.data.model.Contact
import com.agon.app.data.model.Message
import com.agon.app.data.model.MessageType
import com.agon.app.data.repository.ChatRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ChatViewModel(private val repository: ChatRepository) : ViewModel() {
    
    val chats: Flow<List<Chat>> = repository.chats
    
    private val _currentMessages = MutableStateFlow<List<Message>>(emptyList())
    val currentMessages: StateFlow<List<Message>> = _currentMessages.asStateFlow()
    
    private val _sendMessageState = MutableStateFlow<SendMessageState>(SendMessageState.Initial)
    val sendMessageState: StateFlow<SendMessageState> = _sendMessageState.asStateFlow()
    
    private var currentChatId: String? = null
    
    fun getChatsWithContacts(contactsFlow: Flow<List<Contact>>): Flow<List<ChatWithContact>> {
        return repository.getChatsWithContacts(contactsFlow)
    }
    
    fun createChat(participantIds: List<String>, onResult: (Chat) -> Unit) {
        viewModelScope.launch {
            val chat = repository.createChat(participantIds)
            onResult(chat)
        }
    }
    
    fun getOrCreateChatWithContact(contact: Contact, currentUserId: String, onResult: (Chat) -> Unit) {
        viewModelScope.launch {
            val chat = repository.getOrCreateChatWithContact(contact, currentUserId)
            currentChatId = chat.id
            loadMessages(chat.id)
            onResult(chat)
        }
    }
    
    fun loadMessages(chatId: String) {
        currentChatId = chatId
        viewModelScope.launch {
            repository.getMessagesForChat(chatId).collect { messages ->
                _currentMessages.value = messages
            }
        }
    }
    
    fun sendMessage(chatId: String, senderId: String, content: String, type: MessageType = MessageType.TEXT) {
        viewModelScope.launch {
            _sendMessageState.value = SendMessageState.Loading
            try {
                repository.sendMessage(chatId, senderId, content, type)
                _sendMessageState.value = SendMessageState.Success
            } catch (e: Exception) {
                _sendMessageState.value = SendMessageState.Error(e.message ?: "Failed to send message")
            }
        }
    }
    
    fun markMessagesAsRead(chatId: String, userId: String) {
        viewModelScope.launch {
            repository.markMessagesAsRead(chatId, userId)
        }
    }
    
    fun deleteChat(chatId: String) {
        viewModelScope.launch {
            repository.deleteChat(chatId)
        }
    }
    
    fun addSampleChats(userId: String, contacts: List<Contact>) {
        viewModelScope.launch {
            repository.addSampleChats(userId, contacts)
        }
    }
    
    fun clearCurrentChat() {
        currentChatId = null
        _currentMessages.value = emptyList()
    }
    
    companion object {
        fun provideFactory(repository: ChatRepository): ViewModelProvider.Factory = 
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return ChatViewModel(repository) as T
                }
            }
    }
}

sealed class SendMessageState {
    object Initial : SendMessageState()
    object Loading : SendMessageState()
    object Success : SendMessageState()
    data class Error(val message: String) : SendMessageState()
}
