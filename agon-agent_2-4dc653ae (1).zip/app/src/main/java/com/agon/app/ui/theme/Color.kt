package com.agon.app.ui.theme

import androidx.compose.ui.graphics.Color

// WhatsApp Green Theme Colors
val WhatsAppGreen = Color(0xFF128C7E)
val WhatsAppDarkGreen = Color(0xFF075E54)
val WhatsAppLightGreen = Color(0xFF25D366)
val WhatsAppTeal = Color(0xFF34B7F1)
val WhatsAppChatBackground = Color(0xFFE5DDD5)
val WhatsAppStatusGreen = Color(0xFF25D366)

// Light theme
val PrimaryLight = WhatsAppGreen
val OnPrimaryLight = Color.White
val PrimaryContainerLight = WhatsAppLightGreen
val OnPrimaryContainerLight = Color.White
val SecondaryLight = WhatsAppDarkGreen
val OnSecondaryLight = Color.White
val BackgroundLight = Color(0xFFF0F2F5)
val OnBackgroundLight = Color(0xFF111B21)
val SurfaceLight = Color.White
val OnSurfaceLight = Color(0xFF111B21)
val SurfaceVariantLight = Color(0xFFF0F2F5)
val OnSurfaceVariantLight = Color(0xFF667781)

// Dark theme
val PrimaryDark = WhatsAppLightGreen
val OnPrimaryDark = Color(0xFF111B21)
val PrimaryContainerDark = WhatsAppGreen
val OnPrimaryContainerDark = Color.White
val SecondaryDark = WhatsAppTeal
val OnSecondaryDark = Color.White
val BackgroundDark = Color(0xFF0B141A)
val OnBackgroundDark = Color(0xFFE9EDEF)
val SurfaceDark = Color(0xFF111B21)
val OnSurfaceDark = Color(0xFFE9EDEF)
val SurfaceVariantDark = Color(0xFF202C33)
val OnSurfaceVariantDark = Color(0xFF8696A0)

// Status indicator colors
val StatusOnline = Color(0xFF25D366)
val StatusOffline = Color(0xFF8696A0)
val StatusTyping = Color(0xFF34B7F1)

// Message bubble colors
val MessageSent = Color(0xFFDCF8C6)
val MessageReceivedLight = Color.White
val MessageReceivedDark = Color(0xFF202C33)
val MessageTimestampLight = Color(0xFF667781)
val MessageTimestampDark = Color(0xFF8696A0)
