package com.agon.app.viewmodel

import androidx.lifecycle.ViewModel
import com.agon.app.data.model.Contact
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SharedViewModel : ViewModel() {
    private val _selectedContact = MutableStateFlow<Contact?>(null)
    val selectedContact: StateFlow<Contact?> = _selectedContact.asStateFlow()
    
    fun selectContact(contact: Contact) {
        _selectedContact.value = contact
    }
    
    fun clearSelectedContact() {
        _selectedContact.value = null
    }
}
