package com.agon.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.agon.app.data.model.Status
import com.agon.app.data.model.StatusType
import com.agon.app.data.model.StatusUpdate
import com.agon.app.data.model.StatusView
import com.agon.app.data.repository.StatusRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class StatusViewModel(private val repository: StatusRepository) : ViewModel() {
    
    val allStatuses = repository.allStatuses
    val myStatuses = repository.myStatuses
    
    private val _currentStatusViews = MutableStateFlow<List<StatusView>>(emptyList())
    val currentStatusViews: StateFlow<List<StatusView>> = _currentStatusViews.asStateFlow()
    
    private val _addStatusState = MutableStateFlow<AddStatusState>(AddStatusState.Initial)
    val addStatusState: StateFlow<AddStatusState> = _addStatusState.asStateFlow()
    
    init {
        viewModelScope.launch {
            repository.clearExpiredStatuses()
        }
    }
    
    fun addStatus(userId: String, username: String, userProfileUrl: String?, mediaUrl: String, caption: String, type: StatusType = StatusType.IMAGE) {
        viewModelScope.launch {
            _addStatusState.value = AddStatusState.Loading
            try {
                repository.addStatus(userId, username, userProfileUrl, mediaUrl, caption, type)
                _addStatusState.value = AddStatusState.Success
            } catch (e: Exception) {
                _addStatusState.value = AddStatusState.Error(e.message ?: "Failed to add status")
            }
        }
    }
    
    fun viewStatus(statusId: String, viewerId: String, viewerUsername: String) {
        viewModelScope.launch {
            repository.viewStatus(statusId, viewerId, viewerUsername)
        }
    }
    
    fun getStatusViewers(statusId: String) {
        viewModelScope.launch {
            val viewers = repository.getStatusViewers(statusId)
            _currentStatusViews.value = viewers
        }
    }
    
    fun deleteStatus(statusId: String) {
        viewModelScope.launch {
            repository.deleteStatus(statusId)
        }
    }
    
    fun hasUnviewedStatuses(statuses: List<StatusUpdate>): Boolean {
        return statuses.any { it.hasUnviewedStatus }
    }
    
    fun resetAddStatusState() {
        _addStatusState.value = AddStatusState.Initial
    }
    
    companion object {
        fun provideFactory(repository: StatusRepository): ViewModelProvider.Factory = 
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return StatusViewModel(repository) as T
                }
            }
    }
}

sealed class AddStatusState {
    object Initial : AddStatusState()
    object Loading : AddStatusState()
    object Success : AddStatusState()
    data class Error(val message: String) : AddStatusState()
}
