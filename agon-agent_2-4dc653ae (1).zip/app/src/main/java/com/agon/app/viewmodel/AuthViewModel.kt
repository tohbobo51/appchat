package com.agon.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.agon.app.data.model.User
import com.agon.app.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuthViewModel(private val repository: AuthRepository) : ViewModel() {
    
    val isLoggedIn = repository.isLoggedIn
    val currentUser = repository.currentUser
    val currentPhoneNumber = repository.currentPhoneNumber
    val currentUsername = repository.currentUsername
    
    private val _authState = MutableStateFlow<AuthState>(AuthState.Initial)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()
    
    private val _verificationState = MutableStateFlow<VerificationState>(VerificationState.Initial)
    val verificationState: StateFlow<VerificationState> = _verificationState.asStateFlow()
    
    private var pendingPhoneNumber: String = ""
    
    fun register(phoneNumber: String, username: String, displayName: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val user = repository.register(phoneNumber, username, displayName)
                _authState.value = AuthState.Success(user)
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.message ?: "Registration failed")
            }
        }
    }
    
    fun login(phoneNumber: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val user = repository.login(phoneNumber)
                if (user != null) {
                    _authState.value = AuthState.Success(user)
                } else {
                    _authState.value = AuthState.Error("User not found")
                }
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.message ?: "Login failed")
            }
        }
    }
    
    fun logout() {
        viewModelScope.launch {
            repository.logout()
            _authState.value = AuthState.Initial
        }
    }
    
    fun verifyPhoneNumber(phoneNumber: String) {
        viewModelScope.launch {
            _verificationState.value = VerificationState.Loading
            try {
                val isValid = repository.verifyPhoneNumber(phoneNumber)
                if (isValid) {
                    pendingPhoneNumber = phoneNumber
                    _verificationState.value = VerificationState.CodeSent(phoneNumber)
                } else {
                    _verificationState.value = VerificationState.Error("Invalid phone number")
                }
            } catch (e: Exception) {
                _verificationState.value = VerificationState.Error(e.message ?: "Verification failed")
            }
        }
    }
    
    fun verifyOTP(otp: String) {
        viewModelScope.launch {
            _verificationState.value = VerificationState.Loading
            try {
                val isValid = repository.verifyOTP(pendingPhoneNumber, otp)
                if (isValid) {
                    _verificationState.value = VerificationState.Verified(pendingPhoneNumber)
                } else {
                    _verificationState.value = VerificationState.Error("Invalid OTP code")
                }
            } catch (e: Exception) {
                _verificationState.value = VerificationState.Error(e.message ?: "OTP verification failed")
            }
        }
    }
    
    fun resetAuthState() {
        _authState.value = AuthState.Initial
    }
    
    fun resetVerificationState() {
        _verificationState.value = VerificationState.Initial
    }
    
    companion object {
        fun provideFactory(repository: AuthRepository): ViewModelProvider.Factory = 
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return AuthViewModel(repository) as T
                }
            }
    }
}

sealed class AuthState {
    object Initial : AuthState()
    object Loading : AuthState()
    data class Success(val user: User) : AuthState()
    data class Error(val message: String) : AuthState()
}

sealed class VerificationState {
    object Initial : VerificationState()
    object Loading : VerificationState()
    data class CodeSent(val phoneNumber: String) : VerificationState()
    data class Verified(val phoneNumber: String) : VerificationState()
    data class Error(val message: String) : VerificationState()
}
