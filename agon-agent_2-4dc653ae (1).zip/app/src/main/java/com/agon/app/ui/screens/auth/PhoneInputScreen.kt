package com.agon.app.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.ui.theme.WhatsAppGreen
import com.agon.app.ui.theme.WhatsAppLightGreen
import com.agon.app.viewmodel.AuthViewModel
import com.agon.app.viewmodel.VerificationState

@Composable
fun PhoneInputScreen(
    viewModel: AuthViewModel,
    onNavigateToVerification: (String) -> Unit,
    onNavigateToRegister: (String) -> Unit
) {
    val verificationState by viewModel.verificationState.collectAsState()
    var phoneNumber by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    
    LaunchedEffect(verificationState) {
        when (verificationState) {
            is VerificationState.CodeSent -> {
                onNavigateToVerification((verificationState as VerificationState.CodeSent).phoneNumber)
                viewModel.resetVerificationState()
            }
            else -> {}
        }
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Icon
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(WhatsAppLightGreen.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Phone,
                    contentDescription = null,
                    modifier = Modifier.size(50.dp),
                    tint = WhatsAppGreen
                )
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            Text(
                text = "Verify your phone number",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = "ChatApp will send an SMS message to verify your phone number. Enter your phone number:",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Country code + Phone number
            OutlinedTextField(
                value = phoneNumber,
                onValueChange = { 
                    phoneNumber = it
                    isError = false
                },
                label = { Text("Phone number") },
                placeholder = { Text("+62 812-3456-7890") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(),
                isError = isError,
                supportingText = if (isError) {
                    { Text("Please enter a valid phone number") }
                } else null,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = WhatsAppGreen,
                    focusedLabelColor = WhatsAppGreen
                )
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Use format: +62 for Indonesia",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            if (verificationState is VerificationState.Loading) {
                CircularProgressIndicator(color = WhatsAppGreen)
            } else {
                Button(
                    onClick = {
                        if (phoneNumber.length >= 10) {
                            viewModel.verifyPhoneNumber(phoneNumber)
                        } else {
                            isError = true
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen)
                ) {
                    Text("NEXT", fontWeight = FontWeight.Bold)
                }
            }
            
            if (verificationState is VerificationState.Error) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = (verificationState as VerificationState.Error).message,
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 14.sp
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text(
                text = "Carrier SMS charges may apply",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
