package com.agon.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.agon.app.data.model.Contact
import com.agon.app.data.model.ContactRequest
import com.agon.app.data.repository.ContactRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ContactViewModel(private val repository: ContactRepository) : ViewModel() {
    
    val contacts = repository.contacts
    val contactRequests = repository.contactRequests
    
    private val _searchResults = MutableStateFlow<List<Contact>>(emptyList())
    val searchResults: StateFlow<List<Contact>> = _searchResults.asStateFlow()
    
    private val _searchState = MutableStateFlow<SearchState>(SearchState.Initial)
    val searchState: StateFlow<SearchState> = _searchState.asStateFlow()
    
    private val _addContactState = MutableStateFlow<AddContactState>(AddContactState.Initial)
    val addContactState: StateFlow<AddContactState> = _addContactState.asStateFlow()
    
    fun searchByUsername(username: String) {
        viewModelScope.launch {
            _searchState.value = SearchState.Loading
            try {
                val results = repository.searchByUsername(username)
                _searchResults.value = results
                _searchState.value = if (results.isEmpty()) SearchState.Empty else SearchState.Success
            } catch (e: Exception) {
                _searchState.value = SearchState.Error(e.message ?: "Search failed")
            }
        }
    }
    
    fun searchByPhoneNumber(phoneNumber: String) {
        viewModelScope.launch {
            _searchState.value = SearchState.Loading
            try {
                val result = repository.searchByPhoneNumber(phoneNumber)
                _searchResults.value = if (result != null) listOf(result) else emptyList()
                _searchState.value = if (result == null) SearchState.Empty else SearchState.Success
            } catch (e: Exception) {
                _searchState.value = SearchState.Error(e.message ?: "Search failed")
            }
        }
    }
    
    fun addContact(contact: Contact) {
        viewModelScope.launch {
            _addContactState.value = AddContactState.Loading
            try {
                repository.addContact(contact)
                _addContactState.value = AddContactState.Success
            } catch (e: Exception) {
                _addContactState.value = AddContactState.Error(e.message ?: "Failed to add contact")
            }
        }
    }
    
    fun removeContact(contactId: String) {
        viewModelScope.launch {
            repository.removeContact(contactId)
        }
    }
    
    fun blockContact(contactId: String) {
        viewModelScope.launch {
            repository.blockContact(contactId)
        }
    }
    
    fun unblockContact(contactId: String) {
        viewModelScope.launch {
            repository.unblockContact(contactId)
        }
    }
    
    fun sendContactRequest(fromUserId: String, fromUsername: String, fromPhoneNumber: String, toUserId: String) {
        viewModelScope.launch {
            repository.sendContactRequest(fromUserId, fromUsername, fromPhoneNumber, toUserId)
        }
    }
    
    fun respondToRequest(requestId: String, accept: Boolean) {
        viewModelScope.launch {
            repository.respondToRequest(requestId, accept)
        }
    }
    
    fun findByPhoneNumber(phoneNumber: String, onResult: (Contact?) -> Unit) {
        viewModelScope.launch {
            val contact = repository.findByPhoneNumber(phoneNumber)
            onResult(contact)
        }
    }
    
    fun findByUsername(username: String, onResult: (Contact?) -> Unit) {
        viewModelScope.launch {
            val contact = repository.findByUsername(username)
            onResult(contact)
        }
    }
    
    fun resetSearch() {
        _searchResults.value = emptyList()
        _searchState.value = SearchState.Initial
    }
    
    fun resetAddContactState() {
        _addContactState.value = AddContactState.Initial
    }
    
    companion object {
        fun provideFactory(repository: ContactRepository): ViewModelProvider.Factory = 
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return ContactViewModel(repository) as T
                }
            }
    }
}

sealed class SearchState {
    object Initial : SearchState()
    object Loading : SearchState()
    object Success : SearchState()
    object Empty : SearchState()
    data class Error(val message: String) : SearchState()
}

sealed class AddContactState {
    object Initial : AddContactState()
    object Loading : AddContactState()
    object Success : AddContactState()
    data class Error(val message: String) : AddContactState()
}
