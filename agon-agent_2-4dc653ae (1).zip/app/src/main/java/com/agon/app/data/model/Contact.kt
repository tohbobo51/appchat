package com.agon.app.data.model

import kotlinx.serialization.Serializable

@Serializable
data class Contact(
    val id: String,
    val userId: String,
    val phoneNumber: String,
    val username: String,
    val displayName: String,
    val profilePictureUrl: String? = null,
    val status: String = "",
    val isBlocked: Boolean = false,
    val addedAt: Long = System.currentTimeMillis()
)

@Serializable
data class ContactRequest(
    val id: String,
    val fromUserId: String,
    val fromUsername: String,
    val fromPhoneNumber: String,
    val toUserId: String,
    val status: RequestStatus = RequestStatus.PENDING,
    val sentAt: Long = System.currentTimeMillis()
)

enum class RequestStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}
