package com.agon.app.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.agon.app.data.model.Contact
import com.agon.app.data.model.ContactRequest
import com.agon.app.data.model.RequestStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.contactDataStore: DataStore<Preferences> by preferencesDataStore(name = "contacts_prefs")

class ContactRepository(private val context: Context) {
    
    private val CONTACTS_KEY = stringPreferencesKey("contacts")
    private val REQUESTS_KEY = stringPreferencesKey("contact_requests")
    
    private val simulatedUsers = listOf(
        Contact("1", "sim1", "+6281234567891", "alice", "Alice Johnson", status = "Available"),
        Contact("2", "sim2", "+6281234567892", "bob", "Bob Smith", status = "Busy"),
        Contact("3", "sim3", "+6281234567893", "charlie", "Charlie Brown", status = "At work"),
        Contact("4", "sim4", "+6281234567894", "diana", "Diana Prince", status = "Hey there!"),
        Contact("5", "sim5", "+6281234567895", "eve", "Eve Davis", status = "Sleeping"),
        Contact("6", "sim6", "+6281234567896", "frank", "Frank Wilson", status = "In a meeting"),
        Contact("7", "sim7", "+6281234567897", "grace", "Grace Lee", status = "Enjoying life"),
        Contact("8", "sim8", "+6281234567898", "henry", "Henry Taylor", status = "Do not disturb")
    )
    
    val contacts: Flow<List<Contact>> = context.contactDataStore.data
        .map { preferences ->
            preferences[CONTACTS_KEY]?.let { Json.decodeFromString(it) } ?: emptyList()
        }
    
    val contactRequests: Flow<List<ContactRequest>> = context.contactDataStore.data
        .map { preferences ->
            preferences[REQUESTS_KEY]?.let { Json.decodeFromString(it) } ?: emptyList()
        }
    
    suspend fun addContact(contact: Contact) {
        val currentContacts = contacts.first().toMutableList()
        if (!currentContacts.any { it.phoneNumber == contact.phoneNumber }) {
            currentContacts.add(contact)
            context.contactDataStore.edit { preferences ->
                preferences[CONTACTS_KEY] = Json.encodeToString(currentContacts)
            }
        }
    }
    
    suspend fun removeContact(contactId: String) {
        val currentContacts = contacts.first().toMutableList()
        currentContacts.removeAll { it.id == contactId }
        context.contactDataStore.edit { preferences ->
            preferences[CONTACTS_KEY] = Json.encodeToString(currentContacts)
        }
    }
    
    suspend fun searchByUsername(username: String): List<Contact> {
        // Search in simulated users and local contacts
        val searchQuery = username.lowercase()
        val localContacts = contacts.first()
        
        val fromSimulated = simulatedUsers.filter { 
            it.username.contains(searchQuery) && 
            !localContacts.any { local -> local.username == it.username }
        }
        
        return fromSimulated
    }
    
    suspend fun searchByPhoneNumber(phoneNumber: String): Contact? {
        // Search in simulated users
        return simulatedUsers.find { it.phoneNumber == phoneNumber }
    }
    
    suspend fun findByPhoneNumber(phoneNumber: String): Contact? {
        val localContacts = contacts.first()
        return localContacts.find { it.phoneNumber == phoneNumber }
            ?: simulatedUsers.find { it.phoneNumber == phoneNumber }
    }
    
    suspend fun findByUsername(username: String): Contact? {
        val searchQuery = username.lowercase()
        val localContacts = contacts.first()
        return localContacts.find { it.username == searchQuery }
            ?: simulatedUsers.find { it.username == searchQuery }
    }
    
    suspend fun sendContactRequest(fromUserId: String, fromUsername: String, fromPhoneNumber: String, toUserId: String) {
        val currentRequests = contactRequests.first().toMutableList()
        val request = ContactRequest(
            id = System.currentTimeMillis().toString(),
            fromUserId = fromUserId,
            fromUsername = fromUsername,
            fromPhoneNumber = fromPhoneNumber,
            toUserId = toUserId
        )
        currentRequests.add(request)
        context.contactDataStore.edit { preferences ->
            preferences[REQUESTS_KEY] = Json.encodeToString(currentRequests)
        }
    }
    
    suspend fun respondToRequest(requestId: String, accept: Boolean) {
        val currentRequests = contactRequests.first().toMutableList()
        val request = currentRequests.find { it.id == requestId }
        request?.let {
            val updatedRequest = it.copy(status = if (accept) RequestStatus.ACCEPTED else RequestStatus.REJECTED)
            currentRequests[currentRequests.indexOf(it)] = updatedRequest
            
            if (accept) {
                // Add to contacts
                val contact = Contact(
                    id = it.fromUserId,
                    userId = it.fromUserId,
                    phoneNumber = it.fromPhoneNumber,
                    username = it.fromUsername,
                    displayName = it.fromUsername
                )
                addContact(contact)
            }
            
            context.contactDataStore.edit { preferences ->
                preferences[REQUESTS_KEY] = Json.encodeToString(currentRequests)
            }
        }
    }
    
    suspend fun blockContact(contactId: String) {
        val currentContacts = contacts.first().toMutableList()
        val index = currentContacts.indexOfFirst { it.id == contactId }
        if (index != -1) {
            currentContacts[index] = currentContacts[index].copy(isBlocked = true)
            context.contactDataStore.edit { preferences ->
                preferences[CONTACTS_KEY] = Json.encodeToString(currentContacts)
            }
        }
    }
    
    suspend fun unblockContact(contactId: String) {
        val currentContacts = contacts.first().toMutableList()
        val index = currentContacts.indexOfFirst { it.id == contactId }
        if (index != -1) {
            currentContacts[index] = currentContacts[index].copy(isBlocked = false)
            context.contactDataStore.edit { preferences ->
                preferences[CONTACTS_KEY] = Json.encodeToString(currentContacts)
            }
        }
    }
}
