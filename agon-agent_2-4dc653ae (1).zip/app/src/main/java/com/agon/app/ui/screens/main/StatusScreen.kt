package com.agon.app.ui.screens.main

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil3.compose.AsyncImage
import com.agon.app.data.model.Status
import com.agon.app.data.model.StatusUpdate
import com.agon.app.data.model.User
import com.agon.app.ui.theme.StatusOnline
import com.agon.app.ui.theme.WhatsAppDarkGreen
import com.agon.app.ui.theme.WhatsAppGreen
import com.agon.app.viewmodel.StatusViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatusScreen(
    currentUser: User,
    statusViewModel: StatusViewModel
) {
    val allStatuses by statusViewModel.allStatuses.collectAsState(initial = emptyList())
    val myStatuses by statusViewModel.myStatuses.collectAsState(initial = emptyList())
    var showMenu by remember { mutableStateOf(false) }
    var viewingStatus by remember { mutableStateOf<StatusUpdate?>(null) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Status") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = WhatsAppDarkGreen,
                    titleContentColor = Color.White
                ),
                actions = {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More",
                            tint = Color.White
                        )
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Status privacy") },
                            onClick = { showMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Settings") },
                            onClick = { showMenu = false }
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            Column {
                FloatingActionButton(
                    onClick = { /* Add text status */ },
                    containerColor = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Text status",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                FloatingActionButton(
                    onClick = { /* Add photo/video status */ },
                    containerColor = WhatsAppGreen
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Camera",
                        tint = Color.White
                    )
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier.padding(paddingValues)
        ) {
            // My Status
            MyStatusItem(
                currentUser = currentUser,
                myStatuses = myStatuses,
                onClick = {
                    if (myStatuses.isNotEmpty()) {
                        viewingStatus = StatusUpdate(
                            userId = currentUser.id,
                            username = currentUser.displayName,
                            userProfileUrl = currentUser.profilePictureUrl,
                            statuses = myStatuses
                        )
                    }
                }
            )
            
            HorizontalDivider()
            
            // Recent updates
            if (allStatuses.isNotEmpty()) {
                Text(
                    text = "Recent updates",
                    modifier = Modifier.padding(16.dp),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(allStatuses) { statusUpdate ->
                        StatusItem(
                            statusUpdate = statusUpdate,
                            onClick = { viewingStatus = statusUpdate }
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No status updates",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
    
    // Status viewer dialog
    viewingStatus?.let { statusUpdate ->
        StatusViewerDialog(
            statusUpdate = statusUpdate,
            currentUserId = currentUser.id,
            onDismiss = { viewingStatus = null },
            onViewStatus = { statusId ->
                statusViewModel.viewStatus(statusId, currentUser.id, currentUser.username)
            }
        )
    }
}

@Composable
fun MyStatusItem(
    currentUser: User,
    myStatuses: List<Status>,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            AsyncImage(
                model = currentUser.profilePictureUrl ?: "https://i.pravatar.cc/150?u=${currentUser.username}",
                contentDescription = null,
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )
            
            // Add status button
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(WhatsAppGreen)
                    .align(Alignment.BottomEnd)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add",
                    tint = Color.White,
                    modifier = Modifier
                        .size(14.dp)
                        .align(Alignment.Center)
                )
            }
        }
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "My Status",
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = if (myStatuses.isEmpty()) 
                    "Tap to add status update" 
                else 
                    "${myStatuses.size} status${if (myStatuses.size > 1) "es" else ""}",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun StatusItem(
    statusUpdate: StatusUpdate,
    onClick: () -> Unit
) {
    val borderColor = if (statusUpdate.hasUnviewedStatus) StatusOnline else MaterialTheme.colorScheme.surfaceVariant
    
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface)
                .padding(3.dp)
                .clip(CircleShape)
                .background(borderColor)
                .padding(3.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface)
        ) {
            AsyncImage(
                model = statusUpdate.userProfileUrl ?: "https://i.pravatar.cc/150?u=${statusUpdate.username}",
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
            )
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = statusUpdate.username,
            fontSize = 12.sp,
            maxLines = 1
        )
    }
}

@Composable
fun StatusViewerDialog(
    statusUpdate: StatusUpdate,
    currentUserId: String,
    onDismiss: () -> Unit,
    onViewStatus: (String) -> Unit
) {
    var currentStatusIndex by remember { mutableIntStateOf(0) }
    val currentStatus = statusUpdate.statuses.getOrNull(currentStatusIndex)
    
    val progress = remember { Animatable(0f) }
    
    LaunchedEffect(currentStatusIndex) {
        progress.snapTo(0f)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 5000, easing = LinearEasing)
        )
        
        if (currentStatusIndex < statusUpdate.statuses.size - 1) {
            currentStatusIndex++
        } else {
            onDismiss()
        }
    }
    
    currentStatus?.let { status ->
        // Mark as viewed
        LaunchedEffect(status.id) {
            if (status.userId != currentUserId) {
                onViewStatus(status.id)
            }
        }
        
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(
                usePlatformDefaultWidth = false,
                decorFitsSystemWindows = false
            )
        ) {
            Box(
                modifier = Modifier.fillMaxSize()
            ) {
                // Status Image
                AsyncImage(
                    model = status.mediaUrl,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize()
                )
                
                // Gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Black.copy(alpha = 0.7f), Color.Transparent)
                            )
                        )
                )
                
                // Progress bars
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 48.dp, start = 8.dp, end = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    statusUpdate.statuses.forEachIndexed { index, _ ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(2.dp)
                                .background(Color.White.copy(alpha = 0.3f))
                        ) {
                            if (index < currentStatusIndex) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.White)
                                )
                            } else if (index == currentStatusIndex) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(progress.value)
                                        .fillMaxHeight()
                                        .background(Color.White)
                                )
                            }
                        }
                    }
                }
                
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 56.dp, start = 16.dp, end = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = statusUpdate.userProfileUrl ?: "https://i.pravatar.cc/150?u=${statusUpdate.username}",
                        contentDescription = null,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                    )
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    Text(
                        text = statusUpdate.username,
                        color = Color.White,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.weight(1f)
                    )
                    
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White
                        )
                    }
                }
                
                // Caption
                if (status.caption.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(16.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.6f))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = status.caption,
                            color = Color.White,
                            fontSize = 14.sp
                        )
                    }
                }
                
                // Tap areas for navigation
                Row(
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable {
                                if (currentStatusIndex > 0) {
                                    currentStatusIndex--
                                }
                            }
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable {
                                if (currentStatusIndex < statusUpdate.statuses.size - 1) {
                                    currentStatusIndex++
                                } else {
                                    onDismiss()
                                }
                            }
                    )
                }
            }
        }
    }
}
