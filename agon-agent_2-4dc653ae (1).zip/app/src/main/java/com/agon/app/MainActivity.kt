package com.agon.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Circle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.lifecycleScope
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import coil3.compose.AsyncImage
import com.agon.app.data.model.Contact
import com.agon.app.util.NavUtils
import com.agon.app.data.model.User
import com.agon.app.data.repository.AuthRepository
import com.agon.app.data.repository.ChatRepository
import com.agon.app.data.repository.ContactRepository
import com.agon.app.data.repository.StatusRepository
import com.agon.app.data.repository.ThemeRepository
import com.agon.app.ui.screens.auth.PhoneInputScreen
import com.agon.app.ui.screens.auth.RegisterScreen
import com.agon.app.ui.screens.auth.VerificationScreen
import com.agon.app.ui.screens.chat.ChatDetailScreen
import com.agon.app.ui.screens.contacts.AddContactScreen
import com.agon.app.ui.screens.contacts.ContactsScreen
import com.agon.app.ui.screens.main.CallsScreen
import com.agon.app.ui.screens.main.ChatsScreen
import com.agon.app.ui.screens.main.StatusScreen
import com.agon.app.ui.screens.settings.SettingsScreen
import com.agon.app.ui.theme.AgonAppTheme
import com.agon.app.ui.theme.WhatsAppDarkGreen
import com.agon.app.viewmodel.AuthViewModel
import com.agon.app.viewmodel.ChatViewModel
import com.agon.app.viewmodel.ContactViewModel
import com.agon.app.viewmodel.SharedViewModel
import com.agon.app.viewmodel.StatusViewModel
import com.agon.app.viewmodel.ThemeViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

class MainActivity : ComponentActivity() {
    
    private val authRepository by lazy { AuthRepository(this) }
    private val contactRepository by lazy { ContactRepository(this) }
    private val chatRepository by lazy { ChatRepository(this) }
    private val statusRepository by lazy { StatusRepository(this) }
    private val themeRepository by lazy { ThemeRepository(this) }
    
    private val authViewModel by viewModels<AuthViewModel> {
        AuthViewModel.provideFactory(authRepository)
    }
    
    private val contactViewModel by viewModels<ContactViewModel> {
        ContactViewModel.provideFactory(contactRepository)
    }
    
    private val chatViewModel by viewModels<ChatViewModel> {
        ChatViewModel.provideFactory(chatRepository)
    }
    
    private val statusViewModel by viewModels<StatusViewModel> {
        StatusViewModel.provideFactory(statusRepository)
    }
    
    private val themeViewModel by viewModels<ThemeViewModel> {
        ThemeViewModel.provideFactory(themeRepository)
    }
    
    private val sharedViewModel by viewModels<SharedViewModel>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        
        // Pre-populate with some contacts
        lifecycleScope.launch {
            val contacts = contactRepository.contacts.first()
            if (contacts.isEmpty()) {
                // Add some sample contacts
                val sampleContacts = listOf(
                    Contact("1", "sim1", "+6281234567891", "alice", "Alice Johnson", status = "Available"),
                    Contact("2", "sim2", "+6281234567892", "bob", "Bob Smith", status = "Busy")
                )
                sampleContacts.forEach {
                    contactRepository.addContact(it)
                }
            }
        }
        
        setContent {
            val isDarkMode by themeViewModel.isDarkMode.collectAsState(initial = false)
            
            AgonAppTheme(darkTheme = isDarkMode) {
                ChatApp(
                    authViewModel = authViewModel,
                    contactViewModel = contactViewModel,
                    chatViewModel = chatViewModel,
                    statusViewModel = statusViewModel,
                    themeViewModel = themeViewModel,
                    sharedViewModel = sharedViewModel
                )
            }
        }
    }
}

@Composable
fun ChatApp(
    authViewModel: AuthViewModel,
    contactViewModel: ContactViewModel,
    chatViewModel: ChatViewModel,
    statusViewModel: StatusViewModel,
    themeViewModel: ThemeViewModel,
    sharedViewModel: SharedViewModel
) {
    val navController = rememberNavController()
    val isLoggedIn by authViewModel.isLoggedIn.collectAsState(initial = false)
    val currentUser by authViewModel.currentUser.collectAsState(initial = null)
    val contacts by contactViewModel.contacts.collectAsState(initial = emptyList())
    
    val startDestination = if (isLoggedIn) "main" else "login"
    
    NavHost(
        navController = navController,
        startDestination = startDestination,
        modifier = Modifier.fillMaxSize()
    ) {
        // Auth flow
        composable("login") {
            PhoneInputScreen(
                viewModel = authViewModel,
                onNavigateToVerification = { phone ->
                    navController.navigate("verification/${NavUtils.encodePhoneNumber(phone)}")
                },
                onNavigateToRegister = { phone ->
                    navController.navigate("register/${NavUtils.encodePhoneNumber(phone)}")
                }
            )
        }
        
        composable(
            route = "verification/{phone}",
            arguments = listOf(navArgument("phone") { type = NavType.StringType })
        ) { backStackEntry ->
            val phone = NavUtils.decodePhoneNumber(backStackEntry.arguments?.getString("phone") ?: "")
            VerificationScreen(
                phoneNumber = phone,
                viewModel = authViewModel,
                onVerificationSuccess = {
                    navController.navigate("register/${NavUtils.encodePhoneNumber(phone)}") {
                        popUpTo("login") { inclusive = true }
                    }
                },
                onNavigateBack = {
                    navController.popBackStack()
                },
                onNavigateToRegister = {
                    navController.navigate("register/${NavUtils.encodePhoneNumber(phone)}") {
                        popUpTo("verification/{phone}") { inclusive = true }
                    }
                }
            )
        }
        
        composable(
            route = "register/{phone}",
            arguments = listOf(navArgument("phone") { type = NavType.StringType })
        ) { backStackEntry ->
            val phone = NavUtils.decodePhoneNumber(backStackEntry.arguments?.getString("phone") ?: "")
            RegisterScreen(
                phoneNumber = phone,
                viewModel = authViewModel,
                onRegistrationSuccess = {
                    navController.navigate("main") {
                        popUpTo("login") { inclusive = true }
                    }
                }
            )
        }
        
        // Main app with bottom nav
        composable("main") {
            currentUser?.let { user ->
                MainScreenWithBottomNav(
                    currentUser = user,
                    contacts = contacts,
                    authViewModel = authViewModel,
                    contactViewModel = contactViewModel,
                    chatViewModel = chatViewModel,
                    statusViewModel = statusViewModel,
                    sharedViewModel = sharedViewModel,
                    navController = navController
                )
            }
        }
        
        // Chat detail
        composable("chat_detail") {
            val selectedContact by sharedViewModel.selectedContact.collectAsState()
            
            currentUser?.let { user ->
                selectedContact?.let { contact ->
                    ChatDetailScreen(
                        contact = contact,
                        currentUser = user,
                        viewModel = chatViewModel,
                        onNavigateBack = {
                            sharedViewModel.clearSelectedContact()
                            navController.popBackStack()
                        }
                    )
                }
            }
        }
        
        // Contacts screen
        composable("contacts") {
            ContactsScreen(
                viewModel = contactViewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToAddContact = {
                    navController.navigate("add_contact")
                },
                onNavigateToChat = { contact ->
                    sharedViewModel.selectContact(contact)
                    navController.navigate("chat_detail")
                }
            )
        }
        
        // Add contact screen
        composable("add_contact") {
            currentUser?.let { user ->
                AddContactScreen(
                    viewModel = contactViewModel,
                    currentUserId = user.id,
                    currentUsername = user.username,
                    currentPhoneNumber = user.phoneNumber,
                    onNavigateBack = { navController.popBackStack() },
                    onContactAdded = { navController.popBackStack() }
                )
            }
        }
        
        // Settings screen
        composable("settings") {
            currentUser?.let { user ->
                SettingsScreen(
                    currentUser = user,
                    themeViewModel = themeViewModel,
                    onLogout = {
                        authViewModel.logout()
                        navController.navigate("login") {
                            popUpTo("main") { inclusive = true }
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}

@Composable
fun MainScreenWithBottomNav(
    currentUser: User,
    contacts: List<Contact>,
    authViewModel: AuthViewModel,
    contactViewModel: ContactViewModel,
    chatViewModel: ChatViewModel,
    statusViewModel: StatusViewModel,
    sharedViewModel: SharedViewModel,
    navController: NavHostController
) {
    val bottomNavController = rememberNavController()
    val navBackStackEntry by bottomNavController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    
    Scaffold(
        bottomBar = {
            BottomNavBar(
                currentRoute = currentRoute,
                onNavigate = { route ->
                    bottomNavController.navigate(route) {
                        popUpTo(bottomNavController.graph.startDestinationId) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                }
            )
        }
    ) { paddingValues ->
        NavHost(
            navController = bottomNavController,
            startDestination = "chats",
            modifier = Modifier.padding(paddingValues)
        ) {
            composable("chats") {
                ChatsScreen(
                    currentUser = currentUser,
                    contacts = contacts,
                    chatViewModel = chatViewModel,
                    contactViewModel = contactViewModel,
                    onNavigateToChat = { contact ->
                        sharedViewModel.selectContact(contact)
                        navController.navigate("chat_detail")
                    },
                    onNavigateToContacts = {
                        navController.navigate("contacts")
                    },
                    onNavigateToSettings = {
                        navController.navigate("settings")
                    }
                )
            }
            
            composable("status") {
                StatusScreen(
                    currentUser = currentUser,
                    statusViewModel = statusViewModel
                )
            }
            
            composable("calls") {
                CallsScreen()
            }
        }
    }
}

@Composable
fun BottomNavBar(
    currentRoute: String?,
    onNavigate: (String) -> Unit
) {
    AnimatedVisibility(
        visible = true,
        enter = slideInVertically { it },
        exit = slideOutVertically { it }
    ) {
        NavigationBar(
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            NavigationBarItem(
                icon = { 
                    Icon(
                        if (currentRoute == "chats") Icons.Filled.Chat else Icons.Default.Chat,
                        contentDescription = "Chats"
                    ) 
                },
                label = { Text("Chats") },
                selected = currentRoute == "chats",
                onClick = { onNavigate("chats") }
            )
            
            NavigationBarItem(
                icon = { 
                    Icon(
                        Icons.Default.Circle,
                        contentDescription = "Status"
                    ) 
                },
                label = { Text("Status") },
                selected = currentRoute == "status",
                onClick = { onNavigate("status") }
            )
            
            NavigationBarItem(
                icon = { 
                    Icon(
                        if (currentRoute == "calls") Icons.Filled.Call else Icons.Default.Call,
                        contentDescription = "Calls"
                    ) 
                },
                label = { Text("Calls") },
                selected = currentRoute == "calls",
                onClick = { onNavigate("calls") }
            )
        }
    }
}
