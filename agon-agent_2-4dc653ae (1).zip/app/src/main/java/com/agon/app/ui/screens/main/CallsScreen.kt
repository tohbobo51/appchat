package com.agon.app.ui.screens.main

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.agon.app.ui.theme.StatusOnline
import com.agon.app.ui.theme.WhatsAppDarkGreen
import com.agon.app.ui.theme.WhatsAppGreen

// Sample call data
data class CallLog(
    val id: String,
    val name: String,
    val avatarUrl: String?,
    val type: CallType,
    val isVideo: Boolean,
    val timestamp: String,
    val isMissed: Boolean = false
)

enum class CallType {
    INCOMING, OUTGOING
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallsScreen() {
    var showMenu by remember { mutableStateOf(false) }
    
    val sampleCalls = remember {
        listOf(
            CallLog("1", "Alice Johnson", null, CallType.INCOMING, false, "Today, 10:30 AM"),
            CallLog("2", "Bob Smith", null, CallType.OUTGOING, true, "Yesterday, 8:45 PM"),
            CallLog("3", "Charlie Brown", null, CallType.INCOMING, false, "Yesterday, 3:20 PM", true),
            CallLog("4", "Diana Prince", null, CallType.OUTGOING, true, "Monday, 11:00 AM"),
            CallLog("5", "Eve Davis", null, CallType.INCOMING, false, "Sunday, 6:30 PM")
        )
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Calls") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = WhatsAppDarkGreen,
                    titleContentColor = Color.White
                ),
                actions = {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "More",
                            tint = Color.White
                        )
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Clear call log") },
                            onClick = { showMenu = false }
                        )
                        DropdownMenuItem(
                            text = { Text("Settings") },
                            onClick = { showMenu = false }
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { },
                containerColor = WhatsAppGreen
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "New call",
                    tint = Color.White
                )
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier.padding(paddingValues)
        ) {
            items(sampleCalls) { call ->
                CallItem(call = call)
                HorizontalDivider(
                    modifier = Modifier.padding(start = 80.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }
    }
}

@Composable
fun CallItem(call: CallLog) {
    val callIcon = when {
        call.isMissed -> Icons.Default.CallMissed
        call.type == CallType.INCOMING -> Icons.Default.CallReceived
        else -> Icons.Default.CallMade
    }
    
    val callColor = if (call.isMissed) Color(0xFFE53935) else StatusOnline
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Avatar
        AsyncImage(
            model = call.avatarUrl ?: "https://i.pravatar.cc/150?u=${call.name}",
            contentDescription = null,
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
        )
        
        Spacer(modifier = Modifier.width(16.dp))
        
        // Call info
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = call.name,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = callIcon,
                    contentDescription = null,
                    tint = callColor,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = call.timestamp,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        
        // Call button
        IconButton(onClick = { }) {
            Icon(
                imageVector = if (call.isVideo) Icons.Default.Videocam else Icons.Default.Call,
                contentDescription = "Call",
                tint = WhatsAppGreen
            )
        }
    }
}
