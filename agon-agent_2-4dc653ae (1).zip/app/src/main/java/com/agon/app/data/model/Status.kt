package com.agon.app.data.model

import kotlinx.serialization.Serializable

@Serializable
data class Status(
    val id: String,
    val userId: String,
    val username: String,
    val userProfileUrl: String? = null,
    val mediaUrl: String,
    val caption: String = "",
    val type: StatusType = StatusType.IMAGE,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + (24 * 60 * 60 * 1000), // 24 hours
    val views: List<StatusView> = emptyList()
)

@Serializable
data class StatusView(
    val userId: String,
    val username: String,
    val viewedAt: Long = System.currentTimeMillis()
)

enum class StatusType {
    IMAGE,
    VIDEO,
    TEXT
}

@Serializable
data class StatusUpdate(
    val userId: String,
    val username: String,
    val userProfileUrl: String? = null,
    val statuses: List<Status>,
    val hasUnviewedStatus: Boolean = true
)
