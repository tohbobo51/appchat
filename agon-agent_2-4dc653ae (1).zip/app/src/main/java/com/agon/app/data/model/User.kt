package com.agon.app.data.model

import kotlinx.serialization.Serializable

@Serializable
data class User(
    val id: String,
    val phoneNumber: String,
    val username: String,
    val displayName: String,
    val profilePictureUrl: String? = null,
    val status: String = "Hey there! I am using ChatApp.",
    val lastSeen: Long = System.currentTimeMillis(),
    val isOnline: Boolean = false,
    val contacts: List<String> = emptyList()
)

@Serializable
data class UserCredentials(
    val phoneNumber: String,
    val isVerified: Boolean = false,
    val username: String? = null
)
