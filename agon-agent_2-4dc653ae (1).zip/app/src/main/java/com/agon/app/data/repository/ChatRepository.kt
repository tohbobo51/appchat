package com.agon.app.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.agon.app.data.model.Chat
import com.agon.app.data.model.ChatWithContact
import com.agon.app.data.model.Contact
import com.agon.app.data.model.Message
import com.agon.app.data.model.MessageType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.chatDataStore: DataStore<Preferences> by preferencesDataStore(name = "chat_prefs")

class ChatRepository(private val context: Context) {
    
    private val CHATS_KEY = stringPreferencesKey("chats")
    private val MESSAGES_KEY = stringPreferencesKey("messages")
    
    private val sampleMessages = listOf(
        "Hey! How are you?",
        "Did you see the news today?",
        "Let's meet up this weekend!",
        "Thanks for your help yesterday.",
        "I'm running a bit late, be there in 10.",
        "Can you send me that file?",
        "Happy birthday! 🎉",
        "What time works for you?",
        "That was a great movie!",
        "Call me when you're free."
    )
    
    val chats: Flow<List<Chat>> = context.chatDataStore.data
        .map { preferences ->
            preferences[CHATS_KEY]?.let { Json.decodeFromString(it) } ?: emptyList()
        }
    
    val messages: Flow<List<Message>> = context.chatDataStore.data
        .map { preferences ->
            preferences[MESSAGES_KEY]?.let { Json.decodeFromString(it) } ?: emptyList()
        }
    
    fun getChatsWithContacts(contactsFlow: Flow<List<Contact>>): Flow<List<ChatWithContact>> {
        return combine(chats, contactsFlow) { chatList, contactList ->
            chatList.mapNotNull { chat ->
                val contact = contactList.find { contact ->
                    chat.participantIds.contains(contact.userId)
                }
                contact?.let { ChatWithContact(chat, it) }
            }.sortedByDescending { it.chat.lastMessage?.timestamp ?: it.chat.createdAt }
        }
    }
    
    suspend fun createChat(participantIds: List<String>): Chat {
        val currentChats = chats.first().toMutableList()
        
        // Check if chat already exists
        val existingChat = currentChats.find { chat ->
            chat.participantIds.containsAll(participantIds) && participantIds.containsAll(chat.participantIds)
        }
        
        if (existingChat != null) {
            return existingChat
        }
        
        val newChat = Chat(
            id = System.currentTimeMillis().toString(),
            participantIds = participantIds,
            createdAt = System.currentTimeMillis()
        )
        
        currentChats.add(newChat)
        context.chatDataStore.edit { preferences ->
            preferences[CHATS_KEY] = Json.encodeToString(currentChats)
        }
        
        return newChat
    }
    
    suspend fun getOrCreateChatWithContact(contact: Contact, currentUserId: String): Chat {
        return createChat(listOf(currentUserId, contact.userId))
    }
    
    suspend fun sendMessage(chatId: String, senderId: String, content: String, type: MessageType = MessageType.TEXT): Message {
        val message = Message(
            id = System.currentTimeMillis().toString(),
            chatId = chatId,
            senderId = senderId,
            content = content,
            type = type,
            timestamp = System.currentTimeMillis(),
            isDelivered = true
        )
        
        val currentMessages = messages.first().toMutableList()
        currentMessages.add(message)
        context.chatDataStore.edit { preferences ->
            preferences[MESSAGES_KEY] = Json.encodeToString(currentMessages)
        }
        
        // Update chat's last message
        updateChatLastMessage(chatId, message)
        
        return message
    }
    
    private suspend fun updateChatLastMessage(chatId: String, message: Message) {
        val currentChats = chats.first().toMutableList()
        val index = currentChats.indexOfFirst { it.id == chatId }
        if (index != -1) {
            currentChats[index] = currentChats[index].copy(
                lastMessage = message,
                updatedAt = message.timestamp
            )
            context.chatDataStore.edit { preferences ->
                preferences[CHATS_KEY] = Json.encodeToString(currentChats)
            }
        }
    }
    
    fun getMessagesForChat(chatId: String): Flow<List<Message>> {
        return messages.map { messageList ->
            messageList.filter { it.chatId == chatId }.sortedBy { it.timestamp }
        }
    }
    
    suspend fun markMessagesAsRead(chatId: String, userId: String) {
        val currentMessages = messages.first().toMutableList()
        var changed = false
        
        currentMessages.forEachIndexed { index, message ->
            if (message.chatId == chatId && message.senderId != userId && !message.isRead) {
                currentMessages[index] = message.copy(isRead = true)
                changed = true
            }
        }
        
        if (changed) {
            context.chatDataStore.edit { preferences ->
                preferences[MESSAGES_KEY] = Json.encodeToString(currentMessages)
            }
        }
    }
    
    suspend fun deleteChat(chatId: String) {
        val currentChats = chats.first().toMutableList()
        currentChats.removeAll { it.id == chatId }
        context.chatDataStore.edit { preferences ->
            preferences[CHATS_KEY] = Json.encodeToString(currentChats)
        }
        
        // Also delete messages
        val currentMessages = messages.first().toMutableList()
        currentMessages.removeAll { it.chatId == chatId }
        context.chatDataStore.edit { preferences ->
            preferences[MESSAGES_KEY] = Json.encodeToString(currentMessages)
        }
    }
    
    suspend fun addSampleChats(userId: String, contacts: List<Contact>) {
        val currentChats = chats.first()
        if (currentChats.isNotEmpty()) return // Don't add if already have chats
        
        val sampleChats = mutableListOf<Chat>()
        val sampleMessagesList = mutableListOf<Message>()
        
        contacts.take(5).forEachIndexed { index, contact ->
            val chatId = "chat_$index"
            val chat = Chat(
                id = chatId,
                participantIds = listOf(userId, contact.userId),
                createdAt = System.currentTimeMillis() - (index * 86400000)
            )
            sampleChats.add(chat)
            
            // Add sample messages
            val messageCount = (1..5).random()
            repeat(messageCount) { msgIndex ->
                val isFromMe = msgIndex % 2 == 0
                val message = Message(
                    id = "msg_${chatId}_$msgIndex",
                    chatId = chatId,
                    senderId = if (isFromMe) userId else contact.userId,
                    content = sampleMessages.random(),
                    timestamp = System.currentTimeMillis() - ((messageCount - msgIndex) * 3600000),
                    isRead = true,
                    isDelivered = true
                )
                sampleMessagesList.add(message)
            }
            
            // Update chat with last message
            val lastMsg = sampleMessagesList.lastOrNull { it.chatId == chatId }
            sampleChats[sampleChats.indexOf(chat)] = chat.copy(
                lastMessage = lastMsg,
                updatedAt = lastMsg?.timestamp ?: chat.createdAt
            )
        }
        
        context.chatDataStore.edit { preferences ->
            preferences[CHATS_KEY] = Json.encodeToString(sampleChats)
            preferences[MESSAGES_KEY] = Json.encodeToString(sampleMessagesList)
        }
    }
}
