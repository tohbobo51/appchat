package com.agon.app.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.agon.app.data.model.Status
import com.agon.app.data.model.StatusType
import com.agon.app.data.model.StatusUpdate
import com.agon.app.data.model.StatusView
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.statusDataStore: DataStore<Preferences> by preferencesDataStore(name = "status_prefs")

class StatusRepository(private val context: Context) {
    
    private val STATUSES_KEY = stringPreferencesKey("statuses")
    private val MY_STATUSES_KEY = stringPreferencesKey("my_statuses")
    
    // Sample HD status images for demo
    private val sampleStatusImages = listOf(
        "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80",
        "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&q=80",
        "https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=800&q=80",
        "https://images.unsplash.com/photo-1433086966358-54859d0ed716?w=800&q=80",
        "https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=800&q=80",
        "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800&q=80",
        "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&q=80",
        "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?w=800&q=80"
    )
    
    val allStatuses: Flow<List<StatusUpdate>> = context.statusDataStore.data
        .map { preferences ->
            preferences[STATUSES_KEY]?.let { Json.decodeFromString(it) } ?: generateSampleStatuses()
        }
    
    val myStatuses: Flow<List<Status>> = context.statusDataStore.data
        .map { preferences ->
            preferences[MY_STATUSES_KEY]?.let { Json.decodeFromString(it) } ?: emptyList()
        }
    
    private fun generateSampleStatuses(): List<StatusUpdate> {
        val users = listOf(
            Triple("user1", "Alice", "https://i.pravatar.cc/150?u=alice"),
            Triple("user2", "Bob", "https://i.pravatar.cc/150?u=bob"),
            Triple("user3", "Charlie", "https://i.pravatar.cc/150?u=charlie"),
            Triple("user4", "Diana", "https://i.pravatar.cc/150?u=diana"),
            Triple("user5", "Eve", "https://i.pravatar.cc/150?u=eve")
        )
        
        return users.mapIndexed { index, (userId, username, profileUrl) ->
            val statusCount = (1..3).random()
            val statuses = (0 until statusCount).map { statusIndex ->
                Status(
                    id = "status_${userId}_$statusIndex",
                    userId = userId,
                    username = username,
                    userProfileUrl = profileUrl,
                    mediaUrl = sampleStatusImages[(index + statusIndex) % sampleStatusImages.size],
                    caption = listOf(
                        "Having a great day! 🌟",
                        "Beautiful view! 🏔️",
                        "Weekend vibes ✨",
                        "Coffee time ☕",
                        "Nature is amazing 🌿"
                    ).random(),
                    type = StatusType.IMAGE,
                    createdAt = System.currentTimeMillis() - ((statusIndex * 3600000) + (index * 7200000)),
                    views = emptyList()
                )
            }
            StatusUpdate(
                userId = userId,
                username = username,
                userProfileUrl = profileUrl,
                statuses = statuses,
                hasUnviewedStatus = index < 3
            )
        }
    }
    
    suspend fun addStatus(userId: String, username: String, userProfileUrl: String?, mediaUrl: String, caption: String, type: StatusType = StatusType.IMAGE) {
        val newStatus = Status(
            id = System.currentTimeMillis().toString(),
            userId = userId,
            username = username,
            userProfileUrl = userProfileUrl,
            mediaUrl = mediaUrl,
            caption = caption,
            type = type,
            createdAt = System.currentTimeMillis()
        )
        
        val currentStatuses = myStatuses.first().toMutableList()
        currentStatuses.add(newStatus)
        
        // Remove expired statuses
        val now = System.currentTimeMillis()
        val validStatuses = currentStatuses.filter { it.expiresAt > now }
        
        context.statusDataStore.edit { preferences ->
            preferences[MY_STATUSES_KEY] = Json.encodeToString(validStatuses)
        }
    }
    
    suspend fun viewStatus(statusId: String, viewerId: String, viewerUsername: String) {
        val currentStatuses = allStatuses.first().toMutableList()
        
        currentStatuses.forEach { statusUpdate ->
            val statusIndex = statusUpdate.statuses.indexOfFirst { it.id == statusId }
            if (statusIndex != -1) {
                val status = statusUpdate.statuses[statusIndex]
                if (!status.views.any { it.userId == viewerId }) {
                    val updatedViews = status.views + StatusView(viewerId, viewerUsername)
                    val updatedStatuses = statusUpdate.statuses.toMutableList()
                    updatedStatuses[statusIndex] = status.copy(views = updatedViews)
                    
                    val updateIndex = currentStatuses.indexOf(statusUpdate)
                    currentStatuses[updateIndex] = statusUpdate.copy(statuses = updatedStatuses)
                }
            }
        }
        
        context.statusDataStore.edit { preferences ->
            preferences[STATUSES_KEY] = Json.encodeToString(currentStatuses)
        }
    }
    
    suspend fun deleteStatus(statusId: String) {
        val currentStatuses = myStatuses.first().toMutableList()
        currentStatuses.removeAll { it.id == statusId }
        context.statusDataStore.edit { preferences ->
            preferences[MY_STATUSES_KEY] = Json.encodeToString(currentStatuses)
        }
    }
    
    suspend fun getStatusViewers(statusId: String): List<StatusView> {
        val all = allStatuses.first()
        all.forEach { statusUpdate ->
            statusUpdate.statuses.forEach { status ->
                if (status.id == statusId) {
                    return status.views
                }
            }
        }
        return emptyList()
    }
    
    suspend fun clearExpiredStatuses() {
        val now = System.currentTimeMillis()
        
        // Clear my expired statuses
        val myCurrent = myStatuses.first()
        val myValid = myCurrent.filter { it.expiresAt > now }
        
        // Clear all expired statuses
        val allCurrent = allStatuses.first()
        val allValid = allCurrent.map { statusUpdate ->
            val validStatuses = statusUpdate.statuses.filter { it.expiresAt > now }
            statusUpdate.copy(statuses = validStatuses)
        }.filter { it.statuses.isNotEmpty() }
        
        context.statusDataStore.edit { preferences ->
            preferences[MY_STATUSES_KEY] = Json.encodeToString(myValid)
            preferences[STATUSES_KEY] = Json.encodeToString(allValid)
        }
    }
}
