package com.agon.app.util

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.telephony.SmsManager
import android.telephony.SmsMessage
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat

class SMSHelper(private val context: Context) {
    
    private val smsManager: SmsManager = SmsManager.getDefault()
    
    companion object {
        const val SMS_SENT = "SMS_SENT"
        const val SMS_DELIVERED = "SMS_DELIVERED"
        const val TAG = "SMSHelper"
    }
    
    fun sendVerificationSMS(phoneNumber: String, code: String, onSent: (Boolean) -> Unit) {
        try {
            val message = "[ChatApp] Your verification code is: $code. Do not share this code with anyone."
            
            // Pending intents for tracking SMS status
            val sentIntent = PendingIntent.getBroadcast(
                context, 0, Intent(SMS_SENT),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            
            val deliveredIntent = PendingIntent.getBroadcast(
                context, 0, Intent(SMS_DELIVERED),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            
            // Send SMS
            smsManager.sendTextMessage(
                phoneNumber,
                null,
                message,
                sentIntent,
                deliveredIntent
            )
            
            // Register receivers to track status
            registerSMSStatusReceivers(onSent)
            
            Log.d(TAG, "SMS sent to $phoneNumber")
            
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send SMS: ${e.message}")
            Toast.makeText(context, "Failed to send SMS: ${e.message}", Toast.LENGTH_LONG).show()
            onSent(false)
        }
    }
    
    private fun registerSMSStatusReceivers(onSent: (Boolean) -> Unit) {
        // Sent status receiver
        val sentReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (resultCode) {
                    Activity.RESULT_OK -> {
                        Log.d(TAG, "SMS sent successfully")
                        onSent(true)
                    }
                    SmsManager.RESULT_ERROR_GENERIC_FAILURE -> {
                        Log.e(TAG, "SMS generic failure")
                        Toast.makeText(context, "SMS failed to send", Toast.LENGTH_SHORT).show()
                        onSent(false)
                    }
                    SmsManager.RESULT_ERROR_NO_SERVICE -> {
                        Log.e(TAG, "SMS no service")
                        Toast.makeText(context, "No service available", Toast.LENGTH_SHORT).show()
                        onSent(false)
                    }
                    SmsManager.RESULT_ERROR_NULL_PDU -> {
                        Log.e(TAG, "SMS null PDU")
                        onSent(false)
                    }
                    SmsManager.RESULT_ERROR_RADIO_OFF -> {
                        Log.e(TAG, "SMS radio off")
                        Toast.makeText(context, "Radio is off", Toast.LENGTH_SHORT).show()
                        onSent(false)
                    }
                }
                context?.unregisterReceiver(this)
            }
        }
        
        // Delivered status receiver
        val deliveredReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (resultCode) {
                    Activity.RESULT_OK -> {
                        Log.d(TAG, "SMS delivered")
                        Toast.makeText(context, "SMS delivered", Toast.LENGTH_SHORT).show()
                    }
                    Activity.RESULT_CANCELED -> {
                        Log.e(TAG, "SMS not delivered")
                        Toast.makeText(context, "SMS not delivered", Toast.LENGTH_SHORT).show()
                    }
                }
                context?.unregisterReceiver(this)
            }
        }
        
        ContextCompat.registerReceiver(
            context,
            sentReceiver,
            IntentFilter(SMS_SENT),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        
        ContextCompat.registerReceiver(
            context,
            deliveredReceiver,
            IntentFilter(SMS_DELIVERED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }
}

// SMS Receiver to auto-read incoming SMS
class SMSReceiver : BroadcastReceiver() {
    
    companion object {
        var onCodeReceived: ((String) -> Unit)? = null
    }
    
    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent?.action == "android.provider.Telephony.SMS_RECEIVED") {
            val bundle = intent.extras
            if (bundle != null) {
                val pdus = bundle.get("pdus") as Array<*>?
                val format = bundle.getString("format")
                
                pdus?.forEach { pdu ->
                    val smsMessage = SmsMessage.createFromPdu(pdu as ByteArray, format)
                    val sender = smsMessage.displayOriginatingAddress
                    val messageBody = smsMessage.displayMessageBody
                    
                    Log.d("SMSReceiver", "SMS from $sender: $messageBody")
                    
                    // Check if it's from ChatApp
                    if (messageBody.contains("ChatApp") && messageBody.contains("verification code")) {
                        // Extract code (6 digits)
                        val codeRegex = "\\d{6}".toRegex()
                        val code = codeRegex.find(messageBody)?.value
                        
                        code?.let {
                            Log.d("SMSReceiver", "Verification code received: $it")
                            onCodeReceived?.invoke(it)
                        }
                    }
                }
            }
        }
    }
}
