package com.agon.app.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.agon.app.data.model.User
import com.agon.app.data.model.UserCredentials
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "auth_prefs")

class AuthRepository(private val context: Context) {
    
    private val IS_LOGGED_IN = booleanPreferencesKey("is_logged_in")
    private val CURRENT_USER = stringPreferencesKey("current_user")
    private val PHONE_NUMBER = stringPreferencesKey("phone_number")
    private val USERNAME = stringPreferencesKey("username")
    
    val isLoggedIn: Flow<Boolean> = context.dataStore.data
        .map { preferences -> preferences[IS_LOGGED_IN] ?: false }
    
    val currentUser: Flow<User?> = context.dataStore.data
        .map { preferences ->
            preferences[CURRENT_USER]?.let { Json.decodeFromString(it) }
        }
    
    val currentPhoneNumber: Flow<String?> = context.dataStore.data
        .map { preferences -> preferences[PHONE_NUMBER] }
    
    val currentUsername: Flow<String?> = context.dataStore.data
        .map { preferences -> preferences[USERNAME] }
    
    suspend fun register(phoneNumber: String, username: String, displayName: String): User {
        // Simulate user creation
        val user = User(
            id = System.currentTimeMillis().toString(),
            phoneNumber = phoneNumber,
            username = username.lowercase(),
            displayName = displayName,
            isOnline = true
        )
        
        context.dataStore.edit { preferences ->
            preferences[IS_LOGGED_IN] = true
            preferences[CURRENT_USER] = Json.encodeToString(user)
            preferences[PHONE_NUMBER] = phoneNumber
            preferences[USERNAME] = username.lowercase()
        }
        
        return user
    }
    
    suspend fun login(phoneNumber: String): User? {
        // Simulate login - in real app, this would verify against backend
        val user = User(
            id = "user_${phoneNumber.hashCode()}",
            phoneNumber = phoneNumber,
            username = "user_${phoneNumber.takeLast(4)}",
            displayName = "User ${phoneNumber.takeLast(4)}",
            isOnline = true
        )
        
        context.dataStore.edit { preferences ->
            preferences[IS_LOGGED_IN] = true
            preferences[CURRENT_USER] = Json.encodeToString(user)
            preferences[PHONE_NUMBER] = phoneNumber
            preferences[USERNAME] = user.username
        }
        
        return user
    }
    
    suspend fun logout() {
        context.dataStore.edit { preferences ->
            preferences[IS_LOGGED_IN] = false
            preferences.remove(CURRENT_USER)
            preferences.remove(PHONE_NUMBER)
            preferences.remove(USERNAME)
        }
    }
    
    suspend fun updateUser(user: User) {
        context.dataStore.edit { preferences ->
            preferences[CURRENT_USER] = Json.encodeToString(user)
            preferences[USERNAME] = user.username
        }
    }
    
    suspend fun verifyPhoneNumber(phoneNumber: String): Boolean {
        // Simulate verification - accept any 10+ digit number
        return phoneNumber.length >= 10 && phoneNumber.all { it.isDigit() || it == '+' }
    }
    
    suspend fun verifyOTP(phoneNumber: String, otp: String): Boolean {
        // Simulate OTP verification - accept "123456" as valid OTP
        return otp == "123456"
    }
}
