package com.agon.app.ui.screens.auth

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.agon.app.ui.theme.WhatsAppDarkGreen
import com.agon.app.ui.theme.WhatsAppGreen
import com.agon.app.ui.theme.WhatsAppLightGreen
import com.agon.app.util.SMSHelper
import com.agon.app.util.SMSReceiver
import com.agon.app.viewmodel.AuthViewModel
import com.agon.app.viewmodel.VerificationState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VerificationScreen(
    phoneNumber: String,
    viewModel: AuthViewModel,
    onVerificationSuccess: () -> Unit,
    onNavigateBack: () -> Unit,
    onNavigateToRegister: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val smsHelper = remember { SMSHelper(context) }
    val verificationState by viewModel.verificationState.collectAsState()
    
    var otpCode by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var countdown by remember { mutableIntStateOf(60) }
    var generatedCode by remember { mutableStateOf("") }
    var smsSent by remember { mutableStateOf(false) }
    var smsDelivered by remember { mutableStateOf(false) }
    var hasPermission by remember { mutableStateOf(false) }
    var showPermissionDenied by remember { mutableStateOf(false) }
    
    // Generate code immediately
    if (generatedCode.isEmpty()) {
        generatedCode = generateRandomCode()
        android.util.Log.d("Verification", "Generated code: $generatedCode")
    }
    
    // SMS sending logic
    val sendSMS = {
        if (hasPermission && !smsSent && generatedCode.isNotEmpty()) {
            android.util.Log.d("Verification", "Sending SMS with code: $generatedCode")
            smsHelper.sendVerificationSMS(phoneNumber, generatedCode) { success ->
                smsSent = true
                smsDelivered = success
                if (success) {
                    Toast.makeText(context, "SMS sent to $phoneNumber", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    // Permission launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasPermission = isGranted
        if (isGranted) {
            // Send SMS after permission granted
            sendSMS()
        } else {
            showPermissionDenied = true
            Toast.makeText(context, "SMS permission required to send verification code", Toast.LENGTH_LONG).show()
        }
    }
    
    // Check and request permission on launch
    LaunchedEffect(Unit) {
        when (PackageManager.PERMISSION_GRANTED) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) -> {
                hasPermission = true
                sendSMS()
            }
            else -> {
                permissionLauncher.launch(Manifest.permission.SEND_SMS)
            }
        }
    }
    
    // Auto-read SMS receiver
    DisposableEffect(Unit) {
        SMSReceiver.onCodeReceived = { code ->
            otpCode = code
            Toast.makeText(context, "Verification code auto-detected from SMS", Toast.LENGTH_SHORT).show()
        }
        onDispose {
            SMSReceiver.onCodeReceived = null
        }
    }
    
    // Countdown timer for resend
    LaunchedEffect(countdown) {
        if (countdown > 0) {
            delay(1000)
            countdown--
        }
    }
    
    LaunchedEffect(verificationState) {
        when (verificationState) {
            is VerificationState.Verified -> {
                onVerificationSuccess()
                viewModel.resetVerificationState()
            }
            is VerificationState.Error -> {
                isError = true
            }
            else -> {}
        }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Verify") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = WhatsAppDarkGreen,
                    titleContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Icon
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(WhatsAppLightGreen.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(50.dp),
                        tint = WhatsAppGreen
                    )
                }
                
                Spacer(modifier = Modifier.height(32.dp))
                
                Text(
                    text = "Enter OTP Code",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "We've sent a 6-digit verification code via SMS to",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = phoneNumber,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = WhatsAppGreen
                )
                
                Spacer(modifier = Modifier.height(32.dp))
                
                // SMS Status
                when {
                    showPermissionDenied -> {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "SMS Permission Required",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Please grant SMS permission to receive verification code",
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = { permissionLauncher.launch(Manifest.permission.SEND_SMS) },
                                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen)
                                ) {
                                    Text("Grant Permission")
                                }
                            }
                        }
                    }
                    !smsSent -> {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = WhatsAppGreen,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "Sending SMS...",
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    smsDelivered -> {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = WhatsAppGreen.copy(alpha = 0.1f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Sms,
                                        contentDescription = null,
                                        tint = WhatsAppGreen
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "SMS Sent Successfully!",
                                        fontSize = 14.sp,
                                        color = WhatsAppGreen,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                
                                // Show code for testing purposes
                                Text(
                                    text = "Your code:",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = generatedCode,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = WhatsAppGreen,
                                    letterSpacing = 4.sp
                                )
                                
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "(Also sent to your SMS inbox)",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                    else -> {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "Failed to send SMS. Please try again.",
                                modifier = Modifier.padding(16.dp),
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // OTP Input
                OutlinedTextField(
                    value = otpCode,
                    onValueChange = { 
                        if (it.length <= 6 && it.all { char -> char.isDigit() }) {
                            otpCode = it
                            isError = false
                        }
                    },
                    label = { Text("Enter 6-digit code") },
                    placeholder = { Text("000000") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    isError = isError,
                    supportingText = if (isError) {
                        { Text("Invalid verification code. Please check your SMS inbox.") }
                    } else if (smsDelivered) {
                        { Text("Enter the code from your SMS inbox") }
                    } else {
                        { Text("Waiting for SMS...") }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = WhatsAppGreen,
                        focusedLabelColor = WhatsAppGreen
                    ),
                    enabled = smsDelivered
                )
                
                Spacer(modifier = Modifier.height(32.dp))
                
                if (verificationState is VerificationState.Loading) {
                    CircularProgressIndicator(color = WhatsAppGreen)
                } else {
                    Button(
                        onClick = {
                            val inputCode = otpCode.trim()
                            val expectedCode = generatedCode.trim()
                            
                            android.util.Log.d("Verification", "Input: '$inputCode', Expected: '$expectedCode'")
                            
                            if (inputCode == expectedCode && inputCode.isNotEmpty()) {
                                viewModel.verifyOTP(inputCode)
                            } else {
                                isError = true
                                Toast.makeText(
                                    context,
                                    "Invalid code. Expected: $expectedCode, Got: $inputCode",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                        enabled = otpCode.length == 6 && smsDelivered && generatedCode.isNotEmpty()
                    ) {
                        Text("VERIFY", fontWeight = FontWeight.Bold)
                    }
                }
                
                if (verificationState is VerificationState.Error) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = (verificationState as VerificationState.Error).message,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 14.sp
                    )
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Resend section
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Didn't receive code? ",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    
                    if (countdown > 0) {
                        Text(
                            text = "Resend in ${countdown}s",
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        TextButton(
                            onClick = {
                                countdown = 60
                                smsSent = false
                                smsDelivered = false
                                sendSMS()
                            }
                        ) {
                            Text("Resend SMS", color = WhatsAppGreen)
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                TextButton(onClick = onNavigateBack) {
                    Text("Wrong number? Change it", color = WhatsAppGreen)
                }
            }
            
            // SMS Auto-detected notification
            AnimatedVisibility(
                visible = otpCode.length == 6 && smsDelivered,
                modifier = Modifier.align(Alignment.TopCenter),
                enter = slideInVertically { -it },
                exit = slideOutVertically { -it }
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = WhatsAppGreen
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Message,
                            contentDescription = null,
                            tint = Color.White
                        )
                        
                        Spacer(modifier = Modifier.width(12.dp))
                        
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Code detected from SMS!",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Tap VERIFY to continue",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun generateRandomCode(): String {
    return (100000..999999).random().toString()
}
